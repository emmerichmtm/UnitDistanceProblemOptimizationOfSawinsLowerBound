
import math, heapq, json
from functools import lru_cache

def primes_upto(n):
    sieve = bytearray(b'\x01')*(n+1)
    sieve[:2] = b'\x00\x00'
    for p in range(2,int(n**0.5)+1):
        if sieve[p]:
            start=p*p
            sieve[start:n+1:p] = b'\x00'*(((n-start)//p)+1)
    return [i for i,v in enumerate(sieve) if v]

PRIMES=primes_upto(300000)

@lru_cache(None)
def legendre(a,p):
    a%=p
    if a==0: return 0
    r=pow(a,(p-1)//2,p)
    return -1 if r==p-1 else r

def T_first_odd(N):
    return [p for p in PRIMES if p>2][:N]

def status_in_Q(p,T):
    if p==2: return "ramified"
    d=1
    for q in T:
        d=(d*(q%p))%p
        if d==0: return "ramified"
    ls=legendre(d,p)
    return "split" if ls==1 else "inert"

def admissible(p,T,Tset):
    if p==2 or p in Tset or p%4==1:
        return True
    # enough witness: inert in Q(sqrt(q)) for some q in T
    for q in T:
        if q!=p and legendre(q,p)==-1:
            return True
    return False

def select_SQ(T,B):
    Tset=set(T)
    SQ=[]
    for p in PRIMES:
        if p>250000:
            break
        if admissible(p,T,Tset) and status_in_Q(p,T)!="split":
            SQ.append(p)
            if len(SQ)>=B:
                return SQ
    raise RuntimeError(f"not enough primes, got {len(SQ)} of {B}")

def eval_base(T,SQ,R):
    Tset=set(T)
    lnprodT=sum(math.log(q) for q in T)
    C=math.log(1-1/R)+0.5*math.log(2*math.pi/math.e)-0.125*(math.log(4)+lnprodT)-0.5*math.log(0.5*(math.log(4)+lnprodT))
    N=C
    L=0.0
    for p in SQ:
        e=2 if p==2 or p in Tset else 1
        N += (1/(4*e))*math.log(2) # k=1 so log(k+1)=log2
        L += (1/(2*e))*math.log(p)
    D=math.log(2*R)+L # safe: exp large
    return N,D

def optimize_k_for_R(T,SQ,R,max_steps=200000):
    Tset=set(T)
    N,D=eval_base(T,SQ,R)
    k=[1]*len(SQ)
    heap=[]
    for i,p in enumerate(SQ):
        e=2 if p==2 or p in Tset else 1
        a=1/(4*e)
        b=math.log(p)/(2*e)
        # next increment from k=1 to k=2: numerator log(3)-log(2), denominator add log(p)/(2e)
        ratio=a*(math.log(3)-math.log(2))/b
        heapq.heappush(heap,(-ratio,i,a,b))
    steps=0
    while heap and steps<max_steps:
        ratio_neg,i,a,b=heapq.heappop(heap)
        ratio=-ratio_neg
        current=N/D
        if ratio <= current + 1e-15:
            break
        old=k[i]
        dN=a*(math.log(old+2)-math.log(old+1))
        dD=b
        N+=dN; D+=dD; k[i]+=1
        steps+=1
        new=k[i]
        next_ratio=a*(math.log(new+2)-math.log(new+1))/b
        heapq.heappush(heap,(-next_ratio,i,a,b))
    return N/D,k,steps

def optimize_for_N(N, R_values=None):
    T=T_first_odd(N)
    if sum(1 for q in T if q%4==3)%2!=1:
        return None
    B=(N-1)**2//4 - N - 1
    if B<=0: return None
    SQ=select_SQ(T,B)
    if R_values is None:
        R_values=[r/2 for r in range(20,101)] # 10..50 step .5
    best=None
    for R in R_values:
        try:
            d,k,steps=optimize_k_for_R(T,SQ,R)
        except ValueError:
            continue
        if best is None or d>best['delta']:
            best={'N':N,'budget':B,'SQ':len(SQ),'R':R,'delta':d,'kgt1':sum(1 for x in k if x>1),'maxk':max(k),'steps':steps}
    return best

if __name__=='__main__':
    Ns=[13,15,17,21,27,33,39,45,51,57,61,67,73,81,91,101,111,121]
    out=[]
    for N in Ns:
        res=optimize_for_N(N)
        print(res, flush=True)
        if res: out.append(res)
    Path='/mnt/data/variable_T_budget_es_results.json'
    open(Path,'w').write(json.dumps(out,indent=2))
