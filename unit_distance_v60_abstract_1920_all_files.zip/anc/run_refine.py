
import sys,json
sys.path.append('/mnt/data')
import variable_T_budget_es as v
Ns=[13,17,27,39,51,57,67,81,91,101,121]
out=[]
for N in Ns:
    coarse=v.optimize_for_N(N, R_values=[r/2 for r in range(20,121)])
    if coarse is None:
        continue
    R0=coarse['R']
    Rs=[round(R0-1+i*0.02,2) for i in range(101) if R0-1+i*0.02>1.01]
    fine=v.optimize_for_N(N, R_values=Rs)
    print(fine, flush=True)
    out.append(fine)
open('/mnt/data/variable_T_budget_es_results_refined.json','w').write(json.dumps(out,indent=2))
